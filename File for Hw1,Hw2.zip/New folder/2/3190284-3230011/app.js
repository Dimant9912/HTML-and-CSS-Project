window.onload = function hmerominia() {
    const currentDate = new Date();

    const hours = currentDate.getHours();
    const minutes = currentDate.getMinutes();
    const seconds = currentDate.getSeconds();
    if (window.location.pathname.endsWith('/index.html')) {
        if (hours < 12) {
            alert(`${currentDate.toLocaleString()}\nΚαλημέρα,\nστο κατάστημα μας θα βρείτε πληθώρα από Κάρτες Γραφικών σε ασυναγώνιστες τιμές! Για οποιαδήποτε διευκρίνιση είμαστε στη διάθεση σας!`)
        }
        else {
            alert(`${currentDate.toLocaleString()}\nΚαλησπέρα,\nστο κατάστημα μας θα βρείτε πληθώρα από Κάρτες Γραφικών σε ασυναγώνιστες τιμές! Για οποιαδήποτε διευκρίνιση είμαστε στη διάθεση σας!`)
        }

    }
}
const savvas = document.getElementById("savvas")
if (savvas) {
    savvas.addEventListener('click', () => {
        window.location.href = 'mailto:p3190284@aueb.gr';
    })
}
const dhmhtrhs = document.getElementById("dhmhtrhs")
if (dhmhtrhs) {
    dhmhtrhs.addEventListener('click', () => {
        window.location.href = 'mailto:p3230011@aueb.gr';
    })
}





const paragrafos = document.getElementById('paragrafos')
const colorbutton = document.getElementById('colorbutton')

if (colorbutton) {
    colorbutton.addEventListener('click', () => {
        paragrafos.style.backgroundColor = 'rebeccapurple'
    })
}



const startQuizButton = document.getElementById("start-quiz");
const usernameInput = document.getElementById("username");
const questionContainer = document.getElementById("question-container");
const result = document.getElementById("result");
const questionText = document.getElementById("question");
const answerButtons = document.querySelectorAll(".answer-btn");

let score = 0;
let currentQuestionIndex = 0;

const questions = [
    {
        question: "Ποιο από τα παρακάτω είναι επεξεργαστής της Intel;",
        options: [
            "Ryzen 9 5950X",
            "Core i9-13900K", //(Σωστή απάντηση)
            "Epyc 7742"
        ],
        correct: 1,
    },
    {
        question: "Ποια από τις παρακάτω τεχνολογίες είναι χαρακτηριστικό των προϊόντων AMD;",
        options: [
            "Intel Hyper-Threading",
            "AMD Infinity Fabric", //(Σωστή απάντηση)
            "Nvidia CUDA"
        ],
        correct: 1,
    },
    {
        question: "Τι είδους προϊόντα παράγει η Nvidia;",
        options: [
            "Κάρτες γραφικών", //(Σωστή απάντηση)
            "Συσκευές αποθήκευσης",
            "Επεξεργαστές"
        ],
        correct: 0,
    },
    {
        question: "Ποια από τις παρακάτω κατηγορίες ανήκει στα προϊόντα της Samsung;",
        options: [
            "Μνήμες DRAM",
            "Σκληροί δίσκοι SSD", //(Σωστή απάντηση)
            "Επεξεργαστές Ryzen"
        ],
        correct: 1,
    },
    {
        question: "Ποιο από τα παρακάτω είναι προϊόν αποθήκευσης της Crucial;",
        options: [
            "MX500 SSD", //(Σωστή απάντηση)
            "Galaxy Note 20",
            "GeForce RTX 3080"
        ],
        correct: 0,
    },
    {
        question: "Ποια από τις παρακάτω σειρές σκληρών δίσκων ανήκει στην Western Digital;",
        options: [
            "Red", //  (Σωστή απάντηση)
            "Vega",
            "Fury"
        ],
        correct: 0,
    }
];

startQuizButton.addEventListener("click", () => {
    if (usernameInput.value.trim() !== "") {
        alert(`Καλησπέρα ${usernameInput.value}, έτοιμος/η για το Quiz!`);
        startQuiz();
    } else {
        alert("Παρακαλώ πληκτρολογήστε το όνομά σας για να ξεκινήσετε.");
    }
});

function startQuiz() {
    questionContainer.style.display = "block";
    showQuestion();
}

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionText.textContent = currentQuestion.question;
    answerButtons.forEach((button, index) => {
        button.textContent = currentQuestion.options[index];
        button.onclick = () => checkAnswer(index);
    });
}

function checkAnswer(selectedIndex) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedIndex === currentQuestion.correct) {
        score++;
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {

    questionContainer.style.display = "none";
    result.textContent = `Συγχαρητήρια ${usernameInput.value}, το σκορ σας είναι ${score} από ${questions.length} ερωτήσεις.\nΑρα, η εκπτωση σας ειναι ${score}% `;
    result.style.display = "block";

}